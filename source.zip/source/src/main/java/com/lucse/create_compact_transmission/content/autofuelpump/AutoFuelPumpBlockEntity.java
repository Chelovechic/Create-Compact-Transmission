package com.lucse.create_compact_transmission.content.autofuelpump;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.decoration.bracket.BracketedBlockEntityBehaviour;
import com.simibubi.create.content.fluids.FluidPropagator;
import com.simibubi.create.content.fluids.FluidTransportBehaviour;
import com.simibubi.create.content.fluids.pipes.FluidPipeBlock;
import com.simibubi.create.content.fluids.pipes.SmartFluidPipeBlock;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.IFluidHandler.FluidAction;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

import java.lang.reflect.Method;
import java.util.List;

public class AutoFuelPumpBlockEntity extends SmartBlockEntity {

    private static final int TRANSFER_RATE = 100;
    private static final int TICK_RATE = 5;

    private static final String TFMG_ENGINE_CLASS = "com.drmangotea.tfmg.content.engines.base.AbstractEngineBlockEntity";
    private static Class<?> engineClass;
    private static java.lang.reflect.Field fuelTankField;

    static {
        try {
            engineClass = Class.forName(TFMG_ENGINE_CLASS);
            fuelTankField = engineClass.getField("fuelTank");
        } catch (Exception e) {
            engineClass = null;
            fuelTankField = null;
        }
    }

    private int tickCounter = 0;

    public AutoFuelPumpBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
        setLazyTickRate(TICK_RATE);
    }

    @Override
    public void tick() {
        super.tick();
        
        if (level == null)
            return;
        if (engineClass == null)
            return;
        if (!level.isClientSide) {
            tickCounter++;
            if (tickCounter >= TICK_RATE) {
                tickCounter = 0;
                processNeighbors();
            }
        }
    }

    private void processNeighbors() {
        Object fuelTank = null;
        BlockPos enginePos = null;
        IFluidHandler sourceHandler = null;
        for (Direction direction : Direction.values()) {
            BlockPos neighborPos = worldPosition.relative(direction);
            BlockEntity be = level.getBlockEntity(neighborPos);
            
            if (be != null && engineClass.isInstance(be)) {
                try {
                    Object tank = fuelTankField.get(be);
                    java.lang.reflect.Field rpmField = engineClass.getField("rpm");
                    float rpm = rpmField.getFloat(be);
                    java.lang.reflect.Method canWorkMethod = engineClass.getMethod("canWork");
                    boolean canWork = (Boolean) canWorkMethod.invoke(be);
                    
                    if (rpm > 0 && canWork) {
                        Method getSpaceMethod = tank.getClass().getMethod("getSpace");
                        int space = (Integer) getSpaceMethod.invoke(tank);
                        if (space > 0) {
                            fuelTank = tank;
                            enginePos = neighborPos;
                            break;
                        }
                    }
                } catch (Exception e) {
                }
            }
        }
        if (fuelTank == null) {
            return;
        }
        for (Direction direction : Direction.values()) {
            BlockPos neighborPos = worldPosition.relative(direction);
            if (neighborPos.equals(enginePos)) {
                continue;
            }
            if (!FluidPropagator.hasFluidCapability(level, neighborPos, direction.getOpposite())) {
                continue;
            }
            
            BlockEntity sourceBE = level.getBlockEntity(neighborPos);
            if (sourceBE == null) {
                continue;
            }
            BlockState neighborState = level.getBlockState(neighborPos);
            if (isCreatePipe(neighborState.getBlock())) {
                continue;
            }
            
            LazyOptional<IFluidHandler> sourceCap = sourceBE.getCapability(
                ForgeCapabilities.FLUID_HANDLER, 
                direction.getOpposite()
            );
            
            if (!sourceCap.isPresent()) {
                continue;
            }
            
            IFluidHandler handler = sourceCap.orElse(null);
            if (handler == null) {
                continue;
            }
            for (int i = 0; i < handler.getTanks(); i++) {
                FluidStack fluid = handler.getFluidInTank(i);
                if (!fluid.isEmpty() && TFMGEngineProxy.isAllowedFuel(fluid.getFluid())) {
                    sourceHandler = handler;
                    break;
                }
            }
            if (sourceHandler != null) {
                break;
            }
        }
        if (sourceHandler == null) {
            java.util.List<BlockPos> createPipePositions = new java.util.ArrayList<>();
            for (Direction direction : Direction.values()) {
                BlockPos neighborPos = worldPosition.relative(direction);
                if (neighborPos.equals(enginePos)) {
                    continue;
                }
                
                BlockState neighborState = level.getBlockState(neighborPos);
                Block neighborBlock = neighborState.getBlock();
                if (isCreatePipe(neighborBlock)) {
                    if (AutoFuelPumpBlock.canConnectTo(level, neighborPos, neighborState, direction)) {
                        createPipePositions.add(neighborPos);
                    }
                }
            }
            if (createPipePositions.size() != 1) {
                return;
            }
            BlockPos pipePos = createPipePositions.get(0);
            Direction pipeDirection = Direction.getNearest(
                    pipePos.getX() - worldPosition.getX(),
                    pipePos.getY() - worldPosition.getY(),
                    pipePos.getZ() - worldPosition.getZ()
            );
            IFluidHandler foundHandler = findFuelTankThroughPipe(pipePos, pipeDirection.getOpposite(), enginePos);
            if (foundHandler != null) {
                sourceHandler = foundHandler;
            }
        }
        if (fuelTank != null && sourceHandler != null) {
            try {
                Method getSpaceMethod = fuelTank.getClass().getMethod("getSpace");
                int space = (Integer) getSpaceMethod.invoke(fuelTank);
                if (space <= 0) {
                    return;
                }
                FluidStack toTransfer = FluidStack.EMPTY;
                for (int i = 0; i < sourceHandler.getTanks(); i++) {
                    FluidStack fluid = sourceHandler.getFluidInTank(i);
                    if (!fluid.isEmpty() && TFMGEngineProxy.isAllowedFuel(fluid.getFluid())) {
                        toTransfer = fluid.copy();
                        toTransfer.setAmount(Math.min(Math.min(TRANSFER_RATE, space), toTransfer.getAmount()));
                        break;
                    }
                }
                
                if (toTransfer.isEmpty()) {
                    return;
                }
                FluidStack drained = sourceHandler.drain(toTransfer, FluidAction.SIMULATE);
                if (drained.isEmpty() || !TFMGEngineProxy.isAllowedFuel(drained.getFluid())) {
                    return;
                }
                int filled = TFMGEngineProxy.fillFuelTank(fuelTank, drained);
                if (filled > 0) {
                    FluidStack toDrain = drained.copy();
                    toDrain.setAmount(filled);
                    sourceHandler.drain(toDrain, FluidAction.EXECUTE);
                    setChanged();
                }
            } catch (Exception e) {
            }
        }
    }

    @Override
    public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
        behaviours.add(new AutoFuelPumpFluidTransportBehaviour(this));
        behaviours.add(new BracketedBlockEntityBehaviour(this, this::canHaveBracket));
    }

    private boolean canHaveBracket(BlockState state) {
        return true;
    }

    private boolean isCreatePipe(Block block) {
        return block instanceof FluidPipeBlock 
            || block instanceof SmartFluidPipeBlock
            || block == AllBlocks.ENCASED_FLUID_PIPE.get()
            || block == AllBlocks.GLASS_FLUID_PIPE.get();
    }

    private IFluidHandler findFuelTankThroughPipe(BlockPos pipePos, Direction fromDirection, BlockPos enginePos) {
        Set<BlockPos> visited = new HashSet<>();
        Queue<BlockPos> queue = new LinkedList<>();
        queue.add(pipePos);
        visited.add(pipePos);
        visited.add(worldPosition);
        if (enginePos != null) {
            visited.add(enginePos);
        }
        int maxDepth = 32;
        int currentDepth = 0;
        int nodesAtCurrentDepth = 1;
        
        while (!queue.isEmpty() && currentDepth < maxDepth) {
            BlockPos currentPos = queue.poll();
            nodesAtCurrentDepth--;
            for (Direction direction : Direction.values()) {
                BlockPos neighborPos = currentPos.relative(direction);
                
                if (visited.contains(neighborPos)) {
                    continue;
                }
                
                visited.add(neighborPos);
                BlockState neighborState = level.getBlockState(neighborPos);
                Block neighborBlock = neighborState.getBlock();
                if (isCreatePipe(neighborBlock)) {
                    if (FluidPropagator.hasFluidCapability(level, neighborPos, direction.getOpposite())) {
                        queue.add(neighborPos);
                    }
                    continue;
                }
                BlockEntity be = level.getBlockEntity(neighborPos);
                if (be == null) {
                    continue;
                }
                
                LazyOptional<IFluidHandler> cap = be.getCapability(
                    ForgeCapabilities.FLUID_HANDLER, 
                    direction.getOpposite()
                );
                
                if (!cap.isPresent()) {
                    continue;
                }
                
                IFluidHandler handler = cap.orElse(null);
                if (handler == null) {
                    continue;
                }
                for (int i = 0; i < handler.getTanks(); i++) {
                    FluidStack fluid = handler.getFluidInTank(i);
                    if (!fluid.isEmpty() && TFMGEngineProxy.isAllowedFuel(fluid.getFluid())) {
                        return handler;
                    }
                }
            }
            if (nodesAtCurrentDepth == 0) {
                nodesAtCurrentDepth = queue.size();
                currentDepth++;
            }
        }
        return null;
    }

    class AutoFuelPumpFluidTransportBehaviour extends FluidTransportBehaviour {

        public AutoFuelPumpFluidTransportBehaviour(SmartBlockEntity be) {
            super(be);
        }

        @Override
        public boolean canHaveFlowToward(BlockState state, Direction direction) {
            return AutoFuelPumpBlock.isPipe(state)
                    && state.getValue(AutoFuelPumpBlock.PROPERTY_BY_DIRECTION.get(direction));
        }

        @Override
        public AttachmentTypes getRenderedRimAttachment(BlockAndTintGetter world, BlockPos pos, BlockState state,
                                                        Direction direction) {
            AttachmentTypes attachment = super.getRenderedRimAttachment(world, pos, state, direction);

            BlockPos offsetPos = pos.relative(direction);
            BlockState otherState = world.getBlockState(offsetPos);

            if (attachment == AttachmentTypes.RIM) {
                if (!AutoFuelPumpBlock.isPipe(otherState)) {
                    FluidTransportBehaviour pipeBehaviour =
                            BlockEntityBehaviour.get(world, offsetPos, FluidTransportBehaviour.TYPE);
                    if (pipeBehaviour != null && pipeBehaviour.canHaveFlowToward(otherState, direction.getOpposite()))
                        return AttachmentTypes.DETAILED_CONNECTION;
                }

                if (!AutoFuelPumpBlock.shouldDrawRim(world, pos, state, direction))
                    return FluidPropagator.getStraightPipeAxis(state) == direction.getAxis()
                            ? AttachmentTypes.CONNECTION
                            : AttachmentTypes.DETAILED_CONNECTION;
            }

            if (attachment == AttachmentTypes.NONE
                    && state.getValue(AutoFuelPumpBlock.PROPERTY_BY_DIRECTION.get(direction)))
                return AttachmentTypes.DETAILED_CONNECTION;

            return attachment;
        }
    }
}

