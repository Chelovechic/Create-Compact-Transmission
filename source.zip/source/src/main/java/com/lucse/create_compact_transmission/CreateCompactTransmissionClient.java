package com.lucse.create_compact_transmission;

import com.simibubi.create.AllBlocks;
import net.minecraft.client.renderer.block.BlockModelShaper;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ModelEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Map;

@Mod.EventBusSubscriber(modid = CreateCompactTransmission.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class CreateCompactTransmissionClient {
    public static void onCtorClient(IEventBus modEventBus, IEventBus forgeEventBus) {
        modEventBus.addListener(CreateCompactTransmissionClient::init);
        modEventBus.addListener(CreateCompactTransmissionClient::onModelBake);
    }

    public static void init(final FMLClientSetupEvent event) {
    }

    public static void onModelBake(ModelEvent.ModifyBakingResult event) {
        if (!CCTConfig.CLIENT.useCreatePipeAppearanceForAutoFuelPump.get()) {
            return;
        }
        Block ourBlock = CCTBlocks.AUTO_FUEL_PUMP.get();
        Block createPipe = AllBlocks.FLUID_PIPE.get();
        Map<ResourceLocation, BakedModel> modelRegistry = event.getModels();

        for (BlockState ourState : ourBlock.getStateDefinition().getPossibleStates()) {
            BlockState createState = createPipe.defaultBlockState()
                    .setValue(BlockStateProperties.NORTH, ourState.getValue(BlockStateProperties.NORTH))
                    .setValue(BlockStateProperties.SOUTH, ourState.getValue(BlockStateProperties.SOUTH))
                    .setValue(BlockStateProperties.EAST, ourState.getValue(BlockStateProperties.EAST))
                    .setValue(BlockStateProperties.WEST, ourState.getValue(BlockStateProperties.WEST))
                    .setValue(BlockStateProperties.UP, ourState.getValue(BlockStateProperties.UP))
                    .setValue(BlockStateProperties.DOWN, ourState.getValue(BlockStateProperties.DOWN))
                    .setValue(BlockStateProperties.WATERLOGGED, ourState.getValue(BlockStateProperties.WATERLOGGED));

            ResourceLocation ourBlockId = ForgeRegistries.BLOCKS.getKey(ourBlock);
            ResourceLocation createBlockId = ForgeRegistries.BLOCKS.getKey(createPipe);
            ModelResourceLocation ourModelLoc = BlockModelShaper.stateToModelLocation(ourBlockId, ourState);
            ModelResourceLocation createModelLoc = BlockModelShaper.stateToModelLocation(createBlockId, createState);

            BakedModel createModel = modelRegistry.get(createModelLoc);
            if (createModel != null) {
                modelRegistry.put(ourModelLoc, createModel);
            }
        }

        ResourceLocation ourItemModelLoc = new ModelResourceLocation(ForgeRegistries.BLOCKS.getKey(ourBlock), "inventory");
        ResourceLocation createItemModelLoc = new ModelResourceLocation(ForgeRegistries.BLOCKS.getKey(createPipe), "inventory");
        BakedModel createItemModel = modelRegistry.get(createItemModelLoc);
        if (createItemModel != null) {
            modelRegistry.put(ourItemModelLoc, createItemModel);
        }
    }
}

