package com.lucse.create_compact_transmission;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CreateCompactTransmission.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class CCTConfig {

    public static final ClientConfig CLIENT;
    public static final ForgeConfigSpec CLIENT_SPEC;

    static {
        final var pair = new ForgeConfigSpec.Builder().configure(ClientConfig::new);
        CLIENT_SPEC = pair.getRight();
        CLIENT = pair.getLeft();
    }

    public static class ClientConfig {
        public final ForgeConfigSpec.BooleanValue useCreatePipeAppearanceForAutoFuelPump;

        public ClientConfig(ForgeConfigSpec.Builder builder) {
            builder.push("client");
            useCreatePipeAppearanceForAutoFuelPump = builder
                    .comment("Тебе это не надо, поверь")
                    .define("useCreatePipeAppearanceForAutoFuelPump", true);
            builder.pop();
        }
    }
}
